const mongoose = require("mongoose");

module.exports = async () => {
  // password = Pu4pWl6AFzz771Bw

  const mongoUri = process.env.MONGO_URI;
  try {
    const connect = await mongoose.connect(mongoUri, {
      //   useUnifiedTopology: true,
      //   useNewUrlParser: true,
    });

    console.log(`MongoDB connected: ${connect.connection.host}`.cyan.underline);
  } catch (error) {
    console.log(`Error: ${error.message}`.red.bold);
    process.exit(1);
  }
};
